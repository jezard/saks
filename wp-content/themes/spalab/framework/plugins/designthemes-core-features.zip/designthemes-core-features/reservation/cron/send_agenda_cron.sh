#!/bin/sh
cd D:/wamp/www/
php -f D:\wamp\www\Design-Themes\Test\sl\wp-content\plugins\designthemes-core-features/reservation/cron/send_agenda_cron.php