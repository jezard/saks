scnShortcodeMeta = {
	attributes : [
			{
			label : "Background Image",
			id : "background_image_url",
			help : "",
			},
			{
			label : "Background Color",
			id : "bgcolor",
			help : 'Or you can also choose your own color to use as the background',
			controlType : "color-control"
			},
	],
	defaultContent : "<h2>Our Technological services has been improved vastly</h2><h6>Lorem ipsum dolor sit amet, consectetur adipisicing elit sed doeiusmod tempor incididunt ut labore etdolore magna aliqua Ut enim ad minim veniam doeiusmod tempor incididunt ut labore et dolore maga aliqua Ut enim ad minim veniam veniam doeiusmod tempor incididunt ut labore </h6>",
	shortcode : "dt_sc_callout_box_with_moving_bg"

};